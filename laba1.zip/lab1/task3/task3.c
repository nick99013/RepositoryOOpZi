#include <stdio.h>
#include <math.h>

double	f(double x);

void	main(void)
{
	double x;

	while (1)
	{
		printf("Input x: ");
		scanf_s("%lf", &x, 40);
		printf("x = %g\nf = %.4g\n", x, f(x));
	}
}

double	f(double x)
{
	double f;
	f = 1 - 1 / 4 * pow(sin(2 * x), 2) + cos(2 * x);
	return (f);
}
