#include <stdio.h>

extern double x;
extern double result;
void	f();

void	main(void)
{
	while (1)
	{
		printf("Input x: ");
		scanf_s("%lf", &x, 40);
		f();
		printf("x = %g\nf = %.4g\n", x, result);
	}
}