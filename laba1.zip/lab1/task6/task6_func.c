#include <math.h>

double x;
double result;
void	f(void);

void	f(void)
{
	result = 1 - 1 / 4 * pow(sin(2 * x), 2) + cos(2 * x);
}