#include <stdio.h>
#include <math.h>

double x;
double result;
void	f(void);

void	main(void)
{
	while (1)
	{
		printf("Input x: ");
		scanf_s("%lf", &x, 40);
		f();
		printf("x = %g\nf = %.4g\n", x, result);
	}
}

void	f(void)
{
	result  = 1 - 1 / 4 * pow(sin(2 * x), 2) + cos(2 * x);
}