#include <stdio.h>

double	f(x);

void	main(void)
{
	double x;

	while (1)
	{
		printf("Input x: ");
		scanf_s("%lf", &x, 40);
		printf("x = %g\nf = %.4g\n", x, f(x));
	}
}
