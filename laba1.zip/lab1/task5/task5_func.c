#include <math.h>

double	f(double x)
{
	double f;
	f = 1 - 1 / 4 * pow(sin(2 * x), 2) + cos(2 * x);
	return (f);
}
