#ifndef FUNC_H
# include <stdio.h>
# include <math.h>

double x;
double result;
void	f(void);

#endif